#model calibration Jan 5 2021
#TB only

#clean workspace
rm(list = ls())
gc()

#load packages
sapply(c('dplyr', 'deSolve', 
         'readxl', 'stringr', 
         'reshape2', 'ggplot2', 'varhandle', 'here', 'readr'), require, character.only=T)

indir <- paste0(here(),'/param_files')
outdir <- paste0(here(),'/model_outputs')
setwd(indir)

param_df <- read_excel("Epi_model_parameters.xlsx", sheet = 'model_matched_parameters')
pop_init_df <- read_excel("Epi_model_parameters.xlsx", sheet = 'pop_init')

names(param_df)<-str_replace_all(names(param_df), c(" " = "_" , "-" = "_" ))
names(pop_init_df)<-str_replace_all(names(pop_init_df), c(" " = "_" , "-" = "_" ))

#make sure all compartments are integer type for proper indexing#
param_df$TB_compartment<-as.integer(param_df$TB_compartment)
param_df$DR_compartment<-as.integer(param_df$DR_compartment)
param_df$HIV_compartment<-as.integer(param_df$HIV_compartment)
param_df$G_compartment<-as.integer(param_df$G_compartment)
param_df$P_compartment<-as.integer(param_df$P_compartment)

pop_init_df$TB_compartment<-as.integer(pop_init_df$TB_compartment)
pop_init_df$DR_compartment<-as.integer(pop_init_df$DR_compartment)
pop_init_df$HIV_compartment<-as.integer(pop_init_df$HIV_compartment)
pop_init_df$G_compartment<-as.integer(pop_init_df$G_compartment)
 
pop_init_df_TBHIV_temp <- pop_init_df%>%
  group_by(TB_compartment, HIV_compartment)%>%
  summarise(value = sum(initialized_population_in_compartment))%>%
  mutate(compartment_id = paste0("N_", TB_compartment, "_", HIV_compartment),
         dcompartment_id = paste0("dN_", TB_compartment, "_", HIV_compartment))

#View(pop_init_df_TBHIV_temp)

################ DEFINE SETS ###############################

#TB states (TB)
#1:Uninfected, not on IPT;
#2:Uninfected, on IPT; 
#3:LTBI, infected recently (within the past two-years)
#4: LTBI, infected remotely (more than two-years ago)
#5: LTBI, on IPT
#6: Active
#7: Recovered/Treated
#8: LTBI, after IPT

TB_SET<-1:8

#4 HIV compartments (HIV)#
#1 : HIV Negative
#2 : HIV Positive CD4 > 200 - No ART
#3 : HIV Positive CD4 =<: 200 - No Art
#4 : HIV Positive - ART 

HIV_SET<-1:4

#param extraction

#beta
beta <- param_df%>%
  filter(notation == 'beta')%>%
  group_by(TB_compartment)%>%
  summarise(value = median(Reference_expected_value))

beta <- beta$value
#beta<-1

#phi
phi_h <- array(0, dim = length(HIV_SET))

lapply(HIV_SET, function(h){
  temp <- param_df%>%
    filter(notation == 'phi',
           HIV_compartment == h)
  
  phi_h[h] <<- temp$Reference_expected_value
})

#epsilon

#iota
iota <- param_df%>%
  filter(notation == 'iota', DR_compartment == 1)
iota <- iota$Reference_expected_value

upsilon <- param_df%>%
  filter(notation == 'upsilon')
upsilon <-upsilon$Reference_expected_value

zeta <- param_df%>%
  filter(notation == 'zeta')
zeta <-zeta$Reference_expected_value

#zeta <- .7

kappa_t_h <- array(data = 0, c(length(TB_SET), length(HIV_SET)))



lapply(TB_SET, function(t){
  lapply(HIV_SET, function(h){
  temp <- param_df%>%
    filter(P_compartment == 1,
           notation == 'kappa')%>%
    group_by(TB_compartment, HIV_compartment)%>%
    summarise(value = median(Reference_expected_value))%>%
    filter(TB_compartment == t,
           HIV_compartment == h)
  
  if (nrow(temp) == 1){
    kappa_t_h[t,h] <<- temp$value
  }
})
})

varpi <- param_df%>%
  filter(P_compartment == 1, notation == 'varpi')%>%
  summarise(value = median(Reference_expected_value))

varpi <- varpi$value
#varpi <- 1

omega <-param_df%>%filter(notation == 'omega')
omega <- omega$Reference_expected_value

#omega <- 1

pi_t_t <- array(data = 0, c(length(TB_SET), length(TB_SET)))

lapply(TB_SET, function(t_from){
  lapply(TB_SET, function(t_to){
    num_temp = (t_from*10) + t_to
    
    temp <- param_df%>%
      filter(notation == 'pi',
             TB_compartment == num_temp)
    
    if (nrow(temp) == 1){
      pi_t_t[t_from,t_to] <<- temp$Reference_expected_value
    }
    
  })
})

#test impact of pi_t_t
pi_t_t[8,6] <- .02
#pi_t_t <- pi_t_t*1.5
#pi_t_t[6,7] <- .5
#pi_t_t[4,6]<-.02

#phi
theta_h <-array(0, dim = length(HIV_SET))

lapply(HIV_SET, function(h){
  temp <- param_df%>%
    filter(notation == 'theta',
           HIV_compartment == h)
  
  theta_h[h]<<- temp$Reference_expected_value
  
})

#gamma

eta_i_h <- array(0, dim=c(length(HIV_SET), length(HIV_SET)))

#eta
lapply(HIV_SET, function(h_from){
  lapply(HIV_SET, function(h_to){
    num_temp = (h_from*10) + h_to
    
    temp <- param_df%>%
      filter(notation == 'eta',
             HIV_compartment == num_temp,
             P_compartment == 1,
             G_compartment == 1)
      
    
    
    if (nrow(temp) == 1){
    eta_i_h[h_from, h_to] <<-temp$Reference_expected_value 
    }
    
  })
})

mu_t_h <- array(0, dim = c(length(TB_SET), length(HIV_SET)))

lapply(TB_SET, function(t){
  lapply(HIV_SET, function(h){
    temp <- param_df%>%
      filter(notation == 'mu')%>%
      group_by(TB_compartment, HIV_compartment)%>%
      summarise(value = median(Reference_expected_value))%>%
      filter(TB_compartment == t,
             HIV_compartment == h)
    
    mu_t_h[t,h] <<- temp$value
    
  })
})

#test impacts of mu
#mu_t <- rep(.01, times = length(TB_SET))

alpha_in_t_h <- array(data = 0, c(length(TB_SET), length(HIV_SET)))

lapply(TB_SET, function(t){
  lapply(HIV_SET, function(h){
    temp <- param_df%>%
      filter(notation == 'alpha^in')%>%
      group_by(notation, TB_compartment, HIV_compartment)%>%
      summarise(value = sum(Reference_expected_value))%>%
      filter(TB_compartment == t, HIV_compartment == h)
  
  if (nrow(temp) == 1){
    alpha_in_t_h[t,h] <<- temp$value
  }
  })
})

#alpha_in_t[1] <- 0
#alpha_in_t[3] <- .8
#alpha_in_t[4] <- 0.1923905

alpha_out <- param_df%>%filter(notation == 'alpha^out')
alpha_out <- alpha_out$Reference_expected_value

total_out_t_h <- array(0, dim = length(TB_SET)*length(HIV_SET))
count_temp <- 1

#calculate totals
lapply(TB_SET, function(t){
  lapply(HIV_SET, function(h){
    total_out_t_h[count_temp] <<- (mu_t_h[t,h]*(1-alpha_out))+
      ((1-mu_t_h[t,h])*alpha_out)+
      (mu_t_h[t,h]*alpha_out)
    count_temp <<- count_temp + 1
  })
})

N_init <- pop_init_df_TBHIV_temp$value
names(N_init) <- c(pop_init_df_TBHIV_temp$compartment_id)
N_init[1] <- 13348.5889+10000
N_init[5] <- 13348.5889-10000
#N_init[29] <- 13081.62
N_init[N_t_h_ref[5,1]]

N_t_h_ref <- array(0, dim = c(length(TB_SET), length(HIV_SET)))
count_temp <- 1

lapply(TB_SET, function(t){
  lapply(HIV_SET, function(h){
    N_t_h_ref[t,h] <<- count_temp
    count_temp <<- count_temp + 1
  })
})

open_seir_model<-function(time, N_t_h, parameters){
  
  FOI <- (beta*(sum((phi_h)*N_t_h[N_t_h_ref[6, HIV_SET]])/sum(N_t_h)))
  B <- sum(total_out_t_h*N_t_h)
  
  #set up transition matrix
  transition_mat <-array(0, dim = c(length(N_init), length(N_init)))
  rownames(transition_mat)<-c(pop_init_df_TBHIV_temp$compartment_id)
  colnames(transition_mat)<-c(pop_init_df_TBHIV_temp$compartment_id)
  
  #########TB transitions##############
  lapply(HIV_SET, function(h){
    #Uninfected to on IPT
    transition_mat[N_t_h_ref[1,h],N_t_h_ref[2,h]] <<- kappa_t_h[1,h] 
    #Uninfected, on IPT to infected recently 
    transition_mat[N_t_h_ref[1,h],N_t_h_ref[3,h]] <<- FOI
    #Uninfected to off of IPT
    transition_mat[N_t_h_ref[2,h],N_t_h_ref[1,h]] <<- omega
    #Uninfected, on IPT to LTBI infected recently 
    transition_mat[N_t_h_ref[2,h],N_t_h_ref[3,h]] <<- iota*FOI
    #LTBI, infected recently to LTBI, infected remote
    transition_mat[N_t_h_ref[3,h],N_t_h_ref[4,h]] <<- pi_t_t[3,4]
    #LTBI, infected recently to LTBI, on IPT
    transition_mat[N_t_h_ref[3,h],N_t_h_ref[5,h]] <<-kappa_t_h[3,h]
    #LTBI, infected remotely to LTBI, on IPT
    transition_mat[N_t_h_ref[4,h],N_t_h_ref[5,h]] <<-kappa_t_h[4,h]
    #LTBI, infected remotely to LTBI infected recently
    transition_mat[N_t_h_ref[4,h],N_t_h_ref[3,h]] <<-zeta*FOI
    #TB, infected recently to TB active
    transition_mat[N_t_h_ref[3,h],N_t_h_ref[6,h]] <<-(1/varpi)*theta_h[h]*pi_t_t[3,6]
    #TB, infected remotely to TB active
    transition_mat[N_t_h_ref[4,h],N_t_h_ref[6,h]] <<-(1/varpi)*theta_h[h]*pi_t_t[4,6]
    #TB, LTBI on IPT to TB active
    transition_mat[N_t_h_ref[5,h],N_t_h_ref[6,h]] <<-(1/varpi)*theta_h[h]*pi_t_t[5,6]
    #TB, LTBI on IPT to TB after IPT
    transition_mat[N_t_h_ref[5,h],N_t_h_ref[8,h]]<<-omega
    #recovery rate
    transition_mat[N_t_h_ref[6,h],N_t_h_ref[7,h]]<<-pi_t_t[6,7]
    #recovered to reinfected
    transition_mat[N_t_h_ref[7,h],N_t_h_ref[3,h]]<<-zeta*FOI
    #LTBI after IPT to LTBI, infected recently
    transition_mat[N_t_h_ref[8,h],N_t_h_ref[3,h]]<<-upsilon*FOI
  })
  
  ######HIV Transitions######
  lapply(TB_SET, function(t){
    transition_mat[N_t_h_ref[t,1], N_t_h_ref[t,2]]<<-eta_i_h[1,2]
    transition_mat[N_t_h_ref[t,2], N_t_h_ref[t,3]]<<-eta_i_h[2,3]
    transition_mat[N_t_h_ref[t,2], N_t_h_ref[t,4]]<<-eta_i_h[2,4]
    transition_mat[N_t_h_ref[t,3], N_t_h_ref[t,4]]<<-eta_i_h[3,4]
  })
  
  
  #change vector
  dN_t_h <- array(0, dim = length(TB_SET)*length(HIV_SET))
  names(dN_t_h) <- pop_init_df_TBHIV_temp$dcompartment_id
  
  lapply(TB_SET, function(t){
    lapply(HIV_SET, function(h){
      dN_t_h[N_t_h_ref[t,h]]<<-((sum(transition_mat[, N_t_h_ref[t,h]]*N_t_h[N_t_h_ref[t,h]]))-#gains
                                   (sum(transition_mat[N_t_h_ref[t,h], ])*N_t_h[N_t_h_ref[t,h]])+#losses
                                  (alpha_in_t_h[t,h]*B)-#births
                                  (total_out_t_h[N_t_h_ref[t,h]]*N_t_h[N_t_h_ref[t,h]]))
    })
  })

  list(dN_t_h)
}

#Time Horizon 
TT<-5 #2017-1990
time_interval <- 1/12
TT_SET <- seq(from = 0, to = TT, by = time_interval)

out<-as.data.frame(ode(times = TT_SET, y = N_init, 
         func = open_seir_model, method = 'lsoda',
           parms = NULL))

#out_melt<-melt(data = out, 
 #              id.vars = c("time"))

#colnames(out_melt)[2] <- 'TB_compartment'

#ggplot(out_melt, aes(x = time, y = value, group = TB_compartment, color = TB_compartment))+
#  geom_line()+
#  ylab('total in compartment')

out <-out%>%
  mutate(total_pop = rowSums(.[2:ncol(out)]))

#setwd(outdir)
#write_csv(out, 'out.csv')

out_melt = melt(out, id.vars = c('time', 'total_pop'))
temp <- strsplit(as.character(out_melt$variable), "_")

TB_compartment_temp <- rep(0, times = length(temp))
HIV_compartment_temp <- rep(0, times = length(temp))

for (n in 1:length(temp)){
  listt <- temp[[n]]
  TB_compartment_temp[n] <-listt[2]
  HIV_compartment_temp[n] <- listt[3]
}

out_melt$TB_compartment <- TB_compartment_temp
out_melt$HIV_compartment <- HIV_compartment_temp

out_melt_grouped <- out_melt%>%
  #filter(TB_compartment == '6')%>%
  group_by(TB_compartment, time)%>%
  summarise(total_pop = sum(value))

ggplot(out_melt_grouped, aes(x = time, y = total_pop, group = TB_compartment, color = TB_compartment))+
  geom_line()+
  ylab('total in compartment')

#ggplot(out_melt_grouped%>%filter(TB_compartment=='6'), aes(x = time, y = total_pop))+
#  geom_line()+
#  ylab('total with Active TB')+
#  ylim(0, 30000)
